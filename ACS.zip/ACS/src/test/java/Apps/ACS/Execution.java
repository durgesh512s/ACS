package Apps.ACS;

import java.io.IOException;

import org.testng.annotations.Test;

public class Execution extends Testing {

	@Test
	public void Launch() throws InterruptedException, IOException {

		test.Launch1();
		logMessage("----Launch Application Successfully----");
	}

	@Test(dependsOnMethods = "Launch")
	public void Membership() throws Exception {

		test.Membership1();
		logMessage("Logged in Successfully");

	}

	@Test(dependsOnMethods = "Membership")
	public void FindMembers() throws IOException {

		test.FindMembers1();
		logMessage("Find Members Successfully");
	}

	@Test(dependsOnMethods = "FindMembers")
	public void FindMembership() throws Exception {

		test.FindMembership1();
		logMessage("Find Membership Successfully");

	}

	@Test(dependsOnMethods = "FindMembership")
	public void Individual() throws Exception {

		test.Individual1();
		logMessage("Individuals are Found Successfully");

	}


}
