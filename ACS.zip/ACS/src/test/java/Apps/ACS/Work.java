package Apps.ACS;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Work extends Execution {

	@Test
	public void Acs() {

		driver.get("https://dev-eweb12.acs.org/NFDev4/renew/login/");
		driver.switchTo().frame("eWebFrame");
		driver.findElement(By.xpath("(//input[@type='radio'])[3]")).click();
		driver.findElement(By.xpath("//input[@class='input-user-name']")).sendKeys(id);
		driver.findElement(By.xpath("//input[@class='input-password']")).sendKeys("password");
		driver.findElement(By.xpath("//input[@value='Verify']")).click();
		driver.switchTo().defaultContent();
	}

	@Test(dependsOnMethods = "Acs")
	public void Edit() {
		time(20);
		driver.switchTo().frame("eWebFrame");
		// driver.findElement(By.xpath("//a[contains(text(),'[ edit
		// ]')]")).click();
		driver.findElement(By.xpath("//select[@class='cc']//option[contains(text(),'Visa/MC')]")).click();
		driver.findElement(By.id("e6401c55_2c7c_49c4_bbd4_7ea7d0148393_userControlBillingInformation_tbCardholderName"))
				.sendKeys("ACS TEST");
		driver.findElement(
				By.id("e6401c55_2c7c_49c4_bbd4_7ea7d0148393_userControlBillingInformation_tbCreditCardNumber"))
				.sendKeys("4111111111111111");
		driver.findElement(By.id("e6401c55_2c7c_49c4_bbd4_7ea7d0148393_userControlBillingInformation_tbCcvNumber"))
				.sendKeys("123");
		driver.findElement(By.id("btnContinue")).click();
		driver.findElement(By.id("btnSubmitOmrPayment")).click();
		String s = driver.findElement(By.id("c5824dae_279c_4392_b6d0_3efa2906fbab_lblMembershipExpirationDate"))
				.getText();
		System.out.println(s);
		driver.switchTo().defaultContent();
		driver.findElement(By.id("global-banner")).click();
	}
	/*
	 * @AfterTest public void Close(){ driver.close();
	 */
}
