package Apps.ACS;

import java.io.IOException;

import org.openqa.selenium.By;

public class Testing extends Method {

	String Actualtext;
	String id[] = new String[8];

	public void Launch1() throws InterruptedException, IOException {
		maximize();
		data();
		driver.get(p.getProperty("baseurl"));
	}

	public void Membership1() throws Exception {
		driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[4]")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Membership')]")).click();

	}

	public void FindMembers1() throws IOException {
		data();
		driver.findElement(By.xpath(".//a[@id='F1_HYPERLINK_8']")).click();
	}

	public void FindMembership1() throws Exception {
		time(15);
		logMessage("Member Status= Active Renewed-no Response");
		javascript("document.getElementById('ValueDropDownList4').value='99520115-cfba-4d82-93fc-0db58992acef'");
		javascript("document.getElementById('ValueDropDownList13').value='Peru'");
		driver.findElement(By.id("ButtonSearch")).click();
	}

	public void Individual1() throws Exception {
		time(15);
		driver.findElement(By.xpath("(//td[contains(text(),'Individual')])[1]")).click();
		driver.findElement(By.id("F1_HYPERLINK_4")).click(); // Costumer name
		logMessage("Contact Id=");
		String Contactid = driver.findElement(By.id("F1_cst_id")).getText();
		System.out.println(Contactid);
		id[8] = Contactid;
		logMessage("Customer Name=");
		String Name = driver.findElement(By.id("ChildDivDataFormHeader")).getText();
		System.out.println(Name);
		logMessage("Address=");
		String Address = driver.findElement(By.id("F1_cxa_mailing_label_html")).getText();
		System.out.println(Address);
		javascript("document.getElementById('Link4a8ea18e-56b2-4a57-a652-7ebfee57ba88').click()"); // InvoicesDetails
		hardwait(7);
		logMessage("Invoice No=");
		driver.findElement(By.xpath("(//i[@class='icon-chevron-down'])[1]")).click();
		String InvoiceNo = driver.findElement(By.id("UP24")).getText();
		System.out.println(InvoiceNo);
		logMessage("Date=");
		String Date = driver.findElement(By.id("UP34")).getText();
		System.out.println(Date);
		javascript("document.getElementById('Link8fcfc111-a8ab-453c-973f-71ccd5cd21e2').click()"); // MembershipDetails
		hardwait(7);
		javascript("document.getElementsByClassName('icon-chevron-down')[0].click()");
		logMessage("Join=");
		String join = driver.findElement(By.id("UP34")).getText();
		System.out.println(join);
		logMessage("Expire=");
		String Expire = driver.findElement(By.id("UP40")).getText();
		System.out.println(Expire);
	}

}
